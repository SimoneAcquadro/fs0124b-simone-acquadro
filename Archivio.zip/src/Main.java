import java.util.Scanner;

// Interfaccia per gli elementi riproducibili
interface Riproducibile {
    default void play() {

    }
}

// Classe astratta per gli elementi multimediali
abstract class ElementoMultimediale {
    protected String titolo;
    protected int durata;

    public ElementoMultimediale(String titolo, int durata) {
        this.titolo = titolo;
        this.durata = durata;
    }

    public boolean isRiproducibile() {
        return durata > 0;
    }
}

// Classe per le registrazioni audio
class RegistrazioneAudio extends ElementoMultimediale implements Riproducibile {
    private int volume;

    public RegistrazioneAudio(String titolo, int durata, int volume) {
        super(titolo, durata);
        this.volume = volume;
    }

    public void abbassaVolume() {
        if (volume > 0) {
            volume--;
        }
    }

    public void alzaVolume() {
        volume++;
    }

    @Override
    public void play() {
        if (isRiproducibile()) {
            for (int i = 0; i < durata; i++) {
                System.out.println(titolo + " " + "!".repeat(volume));
            }
        } else {
            System.out.println("Elemento multimediale non riproducibile");
        }
    }
}

// Classe per i video
class Video extends ElementoMultimediale implements Riproducibile {
    private int volume;
    private int luminosita;

    public Video(String titolo, int durata, int volume, int luminosita) {
        super(titolo, durata);
        this.volume = volume;
        this.luminosita = luminosita;
    }

    public void aumentaLuminosita() {
        luminosita++;
    }

    public void diminuisciLuminosita() {
        if (luminosita > 0) {
            luminosita--;
        }
    }

    @Override
    public void play() {
        if (isRiproducibile()) {
            for (int i = 0; i < durata; i++) {
                System.out.println(titolo + " " + "!".repeat(volume) + "*".repeat(luminosita));
            }
        } else {
            System.out.println("Elemento multimediale non riproducibile");
        }
    }
}

// Classe per le immagini
class Immagine extends ElementoMultimediale {
    private int luminosita;

    public Immagine(String titolo, int luminosita) {
        super(titolo, 0); // Le immagini non hanno durata
        this.luminosita = luminosita;
    }

    public void aumentaLuminosita() {
        luminosita++;
    }

    public void diminuisciLuminosita() {
        if (luminosita > 0) {
            luminosita--;
        }
    }

    public void show() {
        System.out.println(titolo + " " + "*".repeat(luminosita));
    }
}

